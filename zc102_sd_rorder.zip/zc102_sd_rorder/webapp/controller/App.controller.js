sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("zc102sdrorder.zc102sdrorder.controller.App", {
    onInit() {
      // 아무것도 없어도 괜찮음
    }
  });
});