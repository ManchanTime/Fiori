/* global QUnit */

sap.ui.require(["zc102sdrorder/zc102sdrorder/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
