sap.ui.define([
	"zc102_sd_rorder/zc102_sd_rorder/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});
